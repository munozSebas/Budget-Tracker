from flask import Flask, render_template, request
from flask_pymongo import PyMongo
from flask_wtf import FlaskForm
from wtforms import StringField, DecimalField, SelectField,DateField
from pymongo import MongoClient
import requests

app = Flask(__name__)
app.config["SECRET_KEY"]="include_a_strong_secret_key"
app.config["MONGO_URI"] = "mongodb+srv://sebasMunoz:Nightwing22@budgettracker.vwphmtk.mongodb.net/?retryWrites=true&w=majority"
#here we are connected
# expenses = MongoClient("mongodb+srv://sebasMunoz:Nightwing22@budgettracker.vwphmtk.mongodb.net/?retryWrites=true&w=majority")
# db = expenses.test
# expense_db = expenses['sm_expenses']
# expense_collect = expense_db.expense_collect
# mongo = PyMongo(app)

client = MongoClient("mongodb+srv://sebasMunoz:Nightwing22@budgettracker.vwphmtk.mongodb.net/?retryWrites=true&w=majority")
db = client.test
sm_db = client['expenses']
sm_expenses = sm_db.sm_expenses
mongo = PyMongo(app)

# test = [{'name': 'sebas', 'fiu': 22}]
#
# result = new_expenses.insert_one(test[0])
# print (result)

other_currencies = [("USD", "United States Dollar"), ("CAD", "Canadian Dollar"), ("EURO", "Euro"),
              ("JPY", "Japanese Yen"), ("MEX", "Mexico Peso"), ("BRL", "Brazilian real")]
class Expenses(FlaskForm):
    categoryChoices = ['rent', 'city', 'water', 'internet', 'insurance', 'restaurants', 'groceries', 'gas', 'college', 'party', 'mortgage']

    description = StringField()
    category = SelectField("Expense Category", choices=categoryChoices)
    cost = DecimalField()
    currency = SelectField("Currency", choices=other_currencies)
    date = DateField()

def get_total_expenses(category):
    total_expenses = 0

    for i in sm_expenses.find({'category': category}, {}):
        total_expenses += float (i['cost'])
    return total_expenses


    # TO BE COMPLETED (please delete the word pass above)
#access the database adding the cost of all documents
#of the category passed as input parameter
#write the appropriate query to retrieve the

def converted_currencies(cost,currency):
    url="http://api.currencylayer.com/live?access_key=lzchoXs8zdPzCjhfFeRJTFFC4DBbp1qF"
    response = requests.get(url).json()
    if currency == 'USD':
        cost_converted = cost
    elif currency == 'CAD':
        cost_converted = cost / response["quotes"]["USDCAD"]
    elif currency == 'EURO':
        cost_converted = cost / response["quotes"]["USDEUR"]
    elif currency == 'JPY':
        cost_converted = cost / response["quotes"]["USDJPY"]
    elif currency == 'MEX':
        cost_converted = cost / response["quotes"]["USDMXN"]
    elif currency == 'BRL':
        cost_converted = cost / response["quotes"]["USDBRL"]
    return cost_converted



@app.route('/', methods=["GET","POST"])
def index():                        #{} inside the find to filter query {description}
    total_cost = 0
    expensesByCategory = []

    for j in sm_expenses.find():
        total_cost += float(j['cost'])
        template_append = (j['category'], get_total_expenses(j['category']))
        if template_append not in expensesByCategory:
            expensesByCategory.append(template_append)

    # print(type(expensesByCategory))
    # expensesByCategory is a list of tuples
    # each tuple has two elements:
    ## a string containing the category label, for example, insurance
    ## the total cost of this category
    return render_template("index.html", expenses=total_cost, expensesByCategory=expensesByCategory )



@app.route('/addExpenses',methods=["GET","POST"])
def addExpenses():
    # INCLUDE THE FORM
    expensesForm = Expenses(request.form)
    if request.method == "POST":
        descriptions = request.form["description"]
        categorys = request.form["category"]
        costs = request.form["cost"]
        dates = request.form["date"]
        currency = request.form["currency"]
        sm_expenses.insert_one({'description':descriptions, 'category':categorys, 'cost':costs,'date':dates, 'currency':currency})
        return render_template("expenseAdded.html")
    return render_template("addExpenses.html",form=expensesForm)

app.run()